package com.example.chris.blackjack;

import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

/**
 * Class for the Settings activity.
 *
 */
public class SettingsActivity extends AppCompatActivity
{
    private SharedPreferences pref;
    EditText numDecks;
    EditText dealerLimit;
    SharedPreferences.Editor editor;

    @Override
    /**
     * initializes the attributes for this class and returns a view with all the needed
     * data set up.
     *
     */
    protected void onCreate(Bundle savedInstanceState)
    {
        pref = getSharedPreferences("settings", Context.MODE_PRIVATE);
        editor = pref.edit();
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_settings);
        numDecks = (EditText) findViewById(R.id.deckID);
        dealerLimit = (EditText) findViewById(R.id.limitID);
        numDecks.setText("" + pref.getInt("numDecks", 4));
        dealerLimit.setText("" + pref.getInt("dealerLimit", 18));
    }

    /**
     *
     * called when the player wants to apply changes.
     * detects out of bounds input in the EditTexts, and applies changes to settings.
     * @param view
     */
    public void doSave(View view)
    {
        int result;
        result = Integer.parseInt(dealerLimit.getText().toString());
        if(result < 22 && result > 0)
        {
            editor.putInt("dealerLimit", result);
        }
        result = Integer.parseInt(numDecks.getText().toString());

        if(result > 0)
        {
            if(result > 6)
            {
                result = 6;
                numDecks.setText("6");
            }

            editor.putInt("numDecks", result);
        }
        editor.apply();
    }


}
