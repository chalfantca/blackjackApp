package com.example.chris.blackjack;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.view.Window;

import static java.lang.Boolean.TRUE;

/**
 * Class for the main screen activity.
 *
 */
public class MainActivity extends AppCompatActivity
{

    @Override
    /**
     * This method is called when the activity is started.  It initializes all of the
     * elements of the class needed for the class to function.  Fields are initialized here.
     */
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        initializeSettings();
    }

    /**
     * this is run the first time the app is ever launched, creates default settings for the game
     * to rely on.  These can be edited later in the settings menu.
     */
    protected void initializeSettings()
    {
        SharedPreferences pref = getSharedPreferences("settings", Context.MODE_PRIVATE);
        int flag = pref.getInt("intialized", 0);
        if(flag == 0)
        {
            SharedPreferences.Editor edit = pref.edit();
            edit.putInt("intialized", 1);
            edit.putInt("numDecks", 4);
            edit.putInt("dealerLimit", 18);
            edit.putBoolean("music", TRUE);
            edit.putBoolean("sfx", TRUE);
            edit.apply();
        }
    }

    /**
     *  Starts the Game Activity
     * @param view
     */
    protected void doPlay(View view)
    {
        Intent intent = new Intent(this, GameActivity.class);
        startActivity(intent);
    }

    /**
     *  starts the Settings Activity
     * @param view
     */
    protected void doSettings(View view)
    {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    /**
     *  Moves program to the background
     * @param view
     */
    protected void doExit(View view)
    {
        finish();
        System.exit(0);
    }
}
