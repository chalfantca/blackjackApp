package com.example.chris.blackjack;

/**
 * Created by Chris on 9/24/2016.
 */

/**
 * this class contains the data representation of a card in the deck.  It
 * holds the type of card, and the card's value, which is calculated
 * during initialization and is used by the GameBoard logic.
 */
public class Card
{
    private String suit;
    private String value;
    private int points;

    /**
     * constructor for a card, requires a suit and value
     * @param newSuit suit of a card, Hearts, Clubs, Diamond or Spades
     * @param newValue Value of 2-10 or jack, king, queen, or ace
     */
    public Card(String newSuit, String newValue)
    {
        setSuit(newSuit);
        setValue(newValue);
        points = calculatePoints(value);
    }

    /**
     * accessor
     * @return points
     */
    public int getPoints()
    {
        return points;
    }

    /**
     * mutator
     * @param points value to set points too
     */
    public void setPoints(int points)
    {
        this.points = points;
    }

    /**
     * this is run during initialization, calculates the points the card is worth
     * based off of the value it was asigned during initialization.
     * @param value value of the card
     * @return points the card is worth
     */
    private int calculatePoints(String value)
    {

        switch(value)
        {
            case "Ace":
                return 11;

            case "King":
                return 10;

            case "Queen":
                return 10;


            case "Jack":
                return 10;

            default:
                return Integer.parseInt(value);

        }

    }

    /**
     * accessor
     * @return value
     */
    public String getValue()
    {
        return value;
    }

    /**
     * mutator
     * @return value of the card
     */
    public void setValue(String value)
    {
        this.value = value;
    }

    /**
     * accesor
     * @return suit of the card
     */
    public String getSuit()
    {return suit;}

    /**
     * mutator
     * @param suit value to set suit too
     */
    public void setSuit(String suit)
    {
        this.suit = suit;
    }
}
