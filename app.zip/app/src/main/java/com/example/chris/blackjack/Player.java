package com.example.chris.blackjack;

import com.example.chris.blackjack.Card;
/**
 * Created by Chris on 9/24/2016.
 */

/**
 * This class is the data representation of a player of the game.  It contains the player's hand, the
 * number of chips they have to gamble with, and other information unique to that particular player.
 *
 */
public class Player
{
    private Card[] hand;
    private int chips;
    private int total;
    private  int numCards;
    private  boolean ace;
    private boolean hard;


    /**
     * Constructor for a player, requires an amount of chips for them to start with.
     * @param numChips
     */
    public Player(int numChips)
    {
        hard = true;
        ace = false;
        chips = numChips;
        emptyHand();
    }

    /**
     * adds a Card object to their hand
     * @param card
     */
    protected void addCard(Card card)
    {
        hand[numCards] = card;
        if(card.getValue().equals("Ace"))
        {
            ace = true;
        }
        numCards++;
        total = calculatePoints();

    }

    /**
     * used to initialize or create a new hand for the player.  All hands are set to 22, because the
     * player cannot possible have 22 cards in their hand.
     */
    protected void emptyHand()
    {
        this.hand = new Card[22];
        numCards = 0;
        total = 0;
    }

    /**
     * this is a method used to calculate the score of hand, it is called each time the hand has
     * a new card added to it.
     *
     * @return the updated value of the hand
     */
    protected int calculatePoints()
    {
        int sum = 0;
        for(int i = 0; i < numCards; i++)
        {
            if(hard)
            {
                sum += hand[i].getPoints();
            }
            else if(hand[i].getValue() == "Ace")
            {
                sum += 1;
            }
            else
            {
                sum += hand[i].getPoints();
            }
        }

        if(sum > 21 && ace && hard)
        {
            hard = false;
            return calculatePoints();
        }
        else {
            return sum;
        }
    }

    /**
     * accessor
     * @return hand array
     */
    public Card[] getHand() {return hand;}

    /**
     * accessor
     * @return total
     */
    public int getTotal()
    {
        return total;
    }

    /**
     * mutator
     * @param total number to set total too.
     */
    public void setTotal(int total)
    {
        this.total = total;
    }

    /**
     * accessor
     * @return chips
     */
    public int getChips()
    {
        return chips;
    }

    /**
     * mutator
     * @param chips number to set chips too.
     */
    public void setChips(int chips)
    {
        this.chips = chips;
    }
}
