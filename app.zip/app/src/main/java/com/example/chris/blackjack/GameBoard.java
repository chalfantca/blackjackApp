package com.example.chris.blackjack;

import android.content.SharedPreferences;

import com.example.chris.blackjack.Card;
import com.example.chris.blackjack.Player;
import java.util.Random;

import java.util.ArrayList;

/**
 * Created by Chris on 9/24/2016.
 */

/**
 * This class handles all the heavy lifting of the game logic.
 *
 * Relies on calls from Game Activity to function.
 *
 */
public class GameBoard extends GameActivity
{
    SharedPreferences pref;
    private ArrayList<Card> deck;
    private Player[] playerList;
    private int cardIndex;

    /**
     * initializes the game's board, setting up the players and deck based off of settings.
     * @param list the list of players from the game Activity
     * @param newPref preferences object initialized int the game activity
     */
    public GameBoard(Player[] list, SharedPreferences newPref)
    {
        pref = newPref;
        this.playerList = list;
        deck = makeDeck(pref.getInt("numDecks", 1));
        shuffle();
    }

    /**
     * this method makes the deck, it runs the loop that makes 1 of each suit/value combo
     * based off of the "numDecks" in the settings menu.
     *
     * @param numDecks setting from settings menu
     * @return array of Cards
     */
    private ArrayList<Card> makeDeck(int numDecks)
    {
        ArrayList<Card> result = new ArrayList<Card>();
        String[] suits = new String[]{"Clubs", "Hearts", "Diamonds", "Spades"};
        String[] values = new String[]{"Ace", "2", "3", "4", "5", "6", "7", "8", "9",
                "10", "Jack", "Queen", "King"};

        for(int n = 0; n < numDecks; n++)
        {
            for(int i = 0; i < suits.length; i++)
            {
                for(int j = 0; j < values.length; j++)
                {
                    result.add(new Card(suits[i], values[j]));
                }
            }
        }

        return  result;
    }

    /**
     * performs a hit, calling an addCard from the top of the deck to the player specified
     * by the param.  This method auto-shuffles the deck whenever 75% of the cards are dealt.
     *
     * Note: Instead of removing a card from the array and placing it in the hand, I simply add a
     * copy of the card, because hands are wiped at the end of a round, and incrementing an index
     * value is a lot simpler than the adding and removing from an array.
     * @param numPlayer
     */
    public void hit(int numPlayer)
    {
        playerList[numPlayer].addCard(deck.get(cardIndex));
        cardIndex++;
        if(cardIndex > (deck.size() * .75))
        {
            shuffle();
        }
    }

    /**
     * takes a deck and creates a duplicate, adding one card from the original deck to the
     * new deck at random, and removing it from the old deck.  Simulates shuffling.
     */
    private void shuffle()
    {
        ArrayList<Card> shuffledDeck = new ArrayList<Card>();
        Random rand = new Random();
        int num;
        while(deck.size() > 0)
        {
            num = rand.nextInt(deck.size());
            shuffledDeck.add(deck.get(num));
            deck.remove(num);
        }
        cardIndex = 0;
        deck = shuffledDeck;
    }

    /**
     * this is a method pending a minor refactor.  It is called at the end of every turn.  The
     * main goal of this method is to handle the end of the round, by making the deal hit until they
     * reach their limit, and then deciding whether the player won or lost, and changing their
     * chips accordingly, it also returns the result of the round back up to the GameActivity, so
     * that it can be output to the screen.
     *
     * @param bet number of chips bet.
     * @return result of the round.
     */
    protected String handleTurns(int bet)
    {
        String newText;
        while((playerList[0].getTotal() < pref.getInt("dealerLimit", 18)) && playerList[1].getTotal() <= 21)
        {
            hit(0);
        }

        if((playerList[0].getTotal() > 21 || playerList[0].getTotal() < playerList[1].getTotal()) && playerList[1].getTotal() <= 21)
        {
            playerList[1].setChips(playerList[1].getChips() + bet);
        }
        else if(playerList[0].getTotal() > playerList[1].getTotal() || playerList[1].getTotal() > 21)
        {
            playerList[1].setChips(playerList[1].getChips() - bet);
        }

        if(playerList[1].getTotal() > 21)
        {
            newText = "Player bust";
        }
        else if(playerList[0].getTotal() > 21)
        {
            newText = "Dealer bust";
        }
        else if(playerList[1].getTotal() > playerList[0].getTotal())
        {
            newText = "Player wins";
        }
        else if(playerList[1].getTotal() < playerList[0].getTotal())
        {
            newText = "Dealer wins by Score";
        }
        else
        {
            //TODO: fix refactor if/else clauses to properly handle results.
            newText = "test";
        }

        for (Player x: playerList)
        {
            x.emptyHand();
        }

        return newText;
    }

    /**
     * This is a WIP method which will predict the probability of a player's hit busting them
     * It needs to be refactored to work with the remaining deck and not the whole deck, and
     * needs to give a recommendation of hit/stay/double.  Might need a second method for the latter.
     * @return percentage chance of busting.
     */
    public double predict()
    {
        double chance = 0.0;
        int limit = 21 - playerList[1].getTotal();
        int total = 0;

        if(limit < 10)
        {
            for (Card card : deck)
            {
                if(card.getPoints() > limit)
                {
                    total++;
                }
            }
            chance =  (deck.size() - cardIndex) / total;
        }

        return chance;
    }
}
