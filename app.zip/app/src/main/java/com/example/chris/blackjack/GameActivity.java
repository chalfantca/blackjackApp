package com.example.chris.blackjack;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


/**
 * Class for the Play Screen, handles manipulation of the play screen and running game events.
 *
 */
public class GameActivity extends AppCompatActivity
{
    SharedPreferences pref;
    private Player[] playerList;
    private GameBoard game;
    private int bet;
    TextView chipsText;
    TextView cardsText;
    TextView resultText;
    EditText betInput;
    Button dealButton;
    Button hitButton;
    Button doubleButton;
    Button standButton;
    double chance;

    @Override
    /**
     *
     * initializes variables at the start of the activity and returns an object
     * containing all of the needed variables
     */
    protected void onCreate(Bundle savedInstanceState)
    {

        pref = getSharedPreferences("settings", Context.MODE_PRIVATE);
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_game);
        int nump = pref.getInt("numPlayers", 2);
        chipsText = (TextView) findViewById(R.id.chipsID);
        cardsText = (TextView) findViewById(R.id.cardsID);
        resultText = (TextView) findViewById(R.id.resultID);
        playerList = createPlayers(nump);
        game = new GameBoard(playerList, pref);
        betInput = (EditText) findViewById(R.id.betID);
        dealButton = (Button) findViewById(R.id.dealID);
        hitButton = (Button) findViewById(R.id.hitID);
        doubleButton = (Button) findViewById(R.id.doubleID);
        standButton = (Button) findViewById(R.id.standID);
        doubleButton.setEnabled(false);
        hitButton.setEnabled(false);
        standButton.setEnabled(false);
        chance = 0.0;
    }

    /**
     * creates an array of players and initialises them with a starting amount of chips.
     *
     * @param numPlayers
     * @return array of players
     */
    protected Player[] createPlayers(int numPlayers)
    {
        Player[] result = new Player[numPlayers];
        result[0] = new Player(0);
        result[1] = new Player(500);
        for(int i = 2; i < numPlayers; i++)
        {
            result[numPlayers] = new Player(400);
        }
        String newText = "Chips: " + result[1].getChips();
        chipsText.setText(newText);
        return result;
    }

    /**
     * deals two cards to each player, also locks in the bet
     *
     * @param view
     */
    protected  void deal(View view)
    {
        dealButton.setEnabled(false);
        resultText.setText("");
        bet = Integer.parseInt(betInput.getText().toString());
        for(int i = 0; i < 2; i++)
        {
            game.hit(0);
            for(int j = 1; j < playerList.length; j++)
            {
                game.hit(j);
            }
        }

        String newText = "Cards: " + playerList[1].getTotal();
        cardsText.setText(newText);
        hitButton.setEnabled(true);
        doubleButton.setEnabled(true);
        standButton.setEnabled(true);

    }

    /**
     * performs a hit, giving the player one card, nd disabling the double button
     *
     * @param view
     */
    protected  void doHit(View view)
    {
        game.hit(1);
        if(playerList[1].getTotal() > 21)
        {
            endRound();
        }
        else
        {
            String newText = "Cards: " + playerList[1].getTotal();
            cardsText.setText(newText);
            doubleButton.setEnabled(false);
            chance = game.predict();
        }
    }

    /**
     * ends the round.
     * @param view
     */
    protected void doStand(View view)
    {
        endRound();
    }

    /**
     *  Deals one card to the player, doubles their bet, and then ends the round.
     * @param view
     */
    protected void doDoubleDown(View view)
    {
        bet = bet * 2;
        game.hit(1);
        String newText = "Cards: " + playerList[1].getTotal();
        cardsText.setText(newText);
        endRound();
    }


    /**
     * processes the tend of the round by calling handleTurns.  Then updates the screen with new
     * information before allowing the player to start a new round.
     *
     */
    protected void endRound()
    {
        String newText = game.handleTurns(bet);
        resultText.setText(newText);
        newText = "Chips: " + playerList[1].getChips();
        chipsText.setText(newText);
        dealButton.setEnabled(true);
        doubleButton.setEnabled(false);
        hitButton.setEnabled(false);
        standButton.setEnabled(false);
    }
}
